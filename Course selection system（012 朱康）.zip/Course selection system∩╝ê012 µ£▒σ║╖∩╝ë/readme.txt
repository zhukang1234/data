1.src里的 com.java.view里的界面是登陆界面，完整系统先运行这个
2.修改数据库信息在src里的com.java.util的DbUtil，默认读写数据库采用UTF-8的编码
3.创建数据库的sql文件在bin里的ser